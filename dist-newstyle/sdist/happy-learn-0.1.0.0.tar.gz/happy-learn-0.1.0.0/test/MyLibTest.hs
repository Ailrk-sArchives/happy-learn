module Main where

import HLearn.Cluster.KMeans

main :: IO ()
main = putStrLn $ show "a"
